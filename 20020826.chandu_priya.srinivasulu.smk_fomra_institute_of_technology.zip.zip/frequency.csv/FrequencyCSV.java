import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class FrequencyCSV {

    public static void main(String[] args) {
        // create a map to store the frequency data
        Map<String, Integer> frequencyMap = new HashMap<>();
        
        // add some sample data
        frequencyMap.put("abide", 10);
        frequencyMap.put("hello", 5);
        frequencyMap.put("world", 2);
        frequencyMap.put("goodbye", 3);
        
        // write the data to a CSV file
        try {
            FileWriter writer = new FileWriter("frequency.csv");
            writer.write("English word,French word,Frequency\n");
            
            for (Map.Entry<String, Integer> entry : frequencyMap.entrySet()) {
                String englishWord = entry.getKey();
                String frenchWord = getFrenchTranslation(englishWord); // replace with your own translation logic
                int frequency = entry.getValue();
                
                writer.write(englishWord + "," + frenchWord + "," + frequency + "\n");
            }
            
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    // example method for getting French translations based on English words
    private static String getFrenchTranslation(String englishWord) {
        switch (englishWord) {
            case "abide":
                return "respecter";
            case "hello":
                return "bonjour";
            case "world":
                return "monde";
            case "goodbye":
                return "au revoir";
            default:
                return "";
}
}
}
